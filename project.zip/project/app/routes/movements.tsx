import { useState } from "react";
import { Layout } from "~/components/layout/layout";
import { mockMovements } from "~/data/movements";
import {
  ArrowRight,
  Package,
  RotateCcw,
  Trash2,
  ArrowLeftRight as Transfer,
  Wrench,
  Settings,
  Clock,
  User,
  FileText,
  CheckCircle,
  AlertCircle,
} from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "~/components/ui/select/select";
import { Button } from "~/components/ui/button/button";
import styles from "./movements.module.css";
import type { Route } from "./+types/movements";

export function meta({}: Route.MetaArgs) {
  return [
    { title: "Движение запчастей - Складской учет" },
    {
      name: "description",
      content: "История перемещений запчастей с фотофиксацией",
    },
  ];
}

const MOVEMENT_TYPE_LABELS: Record<string, string> = {
  issue: "Выдача",
  return: "Возврат",
  writeoff: "Списание",
  transfer: "Перемещение",
  repair: "Восстановление",
  disassembly: "Разукомплектация",
};

const MOVEMENT_ICONS: Record<string, any> = {
  issue: Package,
  return: RotateCcw,
  writeoff: Trash2,
  transfer: Transfer,
  repair: Wrench,
  disassembly: Settings,
};

export default function Movements() {
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const filteredMovements = mockMovements.filter((movement) => {
    const matchesType = typeFilter === "all" || movement.type === typeFilter;
    const matchesStatus =
      statusFilter === "all" ||
      (statusFilter === "approved" && movement.approved) ||
      (statusFilter === "pending" && !movement.approved);

    return matchesType && matchesStatus;
  });

  return (
    <Layout title="Движение запчастей">
      <div className={styles.container}>
        <div className={styles.toolbar}>
          <div className={styles.filters}>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger style={{ width: "200px" }}>
                <SelectValue placeholder="Тип операции" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все операции</SelectItem>
                <SelectItem value="issue">Выдача</SelectItem>
                <SelectItem value="return">Возврат</SelectItem>
                <SelectItem value="writeoff">Списание</SelectItem>
                <SelectItem value="transfer">Перемещение</SelectItem>
                <SelectItem value="repair">Восстановление</SelectItem>
                <SelectItem value="disassembly">Разукомплектация</SelectItem>
              </SelectContent>
            </Select>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger style={{ width: "180px" }}>
                <SelectValue placeholder="Статус" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все статусы</SelectItem>
                <SelectItem value="approved">Подтверждено</SelectItem>
                <SelectItem value="pending">Ожидает подтверждения</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button>Новое перемещение</Button>
        </div>

        <div className={styles.movementsList}>
          {filteredMovements.map((movement) => {
            const Icon = MOVEMENT_ICONS[movement.type];

            return (
              <div key={movement.id} className={`${styles.movementCard} ${!movement.approved ? styles.pending : ""}`}>
                <div className={styles.movementHeader}>
                  <div className={styles.movementTitle}>
                    <Icon className={`${styles.movementIcon} ${styles[movement.type]}`} />
                    <div className={styles.movementTitleText}>
                      <h3 className={styles.movementPartName}>
                        {movement.partName} ({movement.partArticle})
                      </h3>
                      <p className={styles.movementType}>{MOVEMENT_TYPE_LABELS[movement.type]}</p>
                    </div>
                  </div>

                  <div className={styles.movementBadges}>
                    {movement.approved ? (
                      <span className={`${styles.badge} ${styles.approved}`}>
                        <CheckCircle style={{ width: "14px", height: "14px", marginRight: "4px" }} />
                        Подтверждено
                      </span>
                    ) : (
                      <span className={`${styles.badge} ${styles.pending}`}>
                        <AlertCircle style={{ width: "14px", height: "14px", marginRight: "4px" }} />
                        Ожидает подтверждения
                      </span>
                    )}
                  </div>
                </div>

                <div className={styles.movementRoute}>
                  <span className={styles.routePoint}>{movement.from}</span>
                  <ArrowRight className={styles.routeArrow} />
                  <span className={styles.routePoint}>{movement.to}</span>
                </div>

                <div className={styles.movementGrid}>
                  <div className={styles.movementField}>
                    <p className={styles.fieldLabel}>Количество</p>
                    <p className={styles.fieldValue}>{movement.quantity} шт.</p>
                  </div>

                  {movement.equipmentName && (
                    <div className={styles.movementField}>
                      <p className={styles.fieldLabel}>Оборудование</p>
                      <p className={styles.fieldValue}>{movement.equipmentName}</p>
                    </div>
                  )}

                  <div className={styles.movementField}>
                    <p className={styles.fieldLabel}>Ответственный</p>
                    <p className={styles.fieldValue}>{movement.userName}</p>
                  </div>

                  {movement.documentNumber && (
                    <div className={styles.movementField}>
                      <p className={styles.fieldLabel}>Документ 1С</p>
                      <p className={styles.fieldValue}>{movement.documentNumber}</p>
                    </div>
                  )}
                </div>

                {movement.comment && (
                  <div className={styles.movementComment}>
                    <p className={styles.commentLabel}>Комментарий</p>
                    <p className={styles.commentText}>{movement.comment}</p>
                  </div>
                )}

                {(movement.photosBefore || movement.photosAfter) && (
                  <div className={styles.movementPhotos}>
                    {movement.photosBefore && (
                      <div className={styles.photoGroup}>
                        <p className={styles.photoLabel}>Фото до</p>
                        <div className={styles.photoGrid}>
                          {movement.photosBefore.map((photo, idx) => (
                            <img key={idx} src={photo} alt="До" className={styles.photo} />
                          ))}
                        </div>
                      </div>
                    )}

                    {movement.photosAfter && (
                      <div className={styles.photoGroup}>
                        <p className={styles.photoLabel}>Фото после</p>
                        <div className={styles.photoGrid}>
                          {movement.photosAfter.map((photo, idx) => (
                            <img key={idx} src={photo} alt="После" className={styles.photo} />
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                <div className={styles.movementFooter}>
                  <div className={styles.footerInfo}>
                    <span>
                      <Clock style={{ width: "14px", height: "14px", display: "inline", marginRight: "4px" }} />
                      {new Date(movement.timestamp).toLocaleString("ru-RU")}
                    </span>

                    {movement.approved && movement.approvedBy && (
                      <span>
                        <User style={{ width: "14px", height: "14px", display: "inline", marginRight: "4px" }} />
                        Подтвердил: {movement.approvedBy}
                      </span>
                    )}
                  </div>

                  <div className={styles.footerActions}>
                    {!movement.approved && (
                      <>
                        <Button size="sm" variant="outline">
                          Отклонить
                        </Button>
                        <Button size="sm">Подтвердить</Button>
                      </>
                    )}
                    {movement.approved && (
                      <Button size="sm" variant="outline">
                        <FileText style={{ width: "14px", height: "14px", marginRight: "6px" }} />
                        Документ
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </Layout>
  );
}
