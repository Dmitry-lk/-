import { Layout } from "~/components/layout/layout";
import { mockParts } from "~/data/parts";
import { mockMovements } from "~/data/movements";
import { Package, AlertTriangle, TrendingDown, ArrowLeftRight, Clock, CheckCircle } from "lucide-react";
import styles from "./home.module.css";
import type { Route } from "./+types/home";

export function meta({}: Route.MetaArgs) {
  return [
    { title: "Панель управления - Складской учет" },
    {
      name: "description",
      content: "Система управления складским учетом запчастей",
    },
  ];
}

export default function Home() {
  const totalParts = mockParts.length;
  const lowStockParts = mockParts.filter((p) => p.quantity <= p.minQuantity);
  const negativeStockParts = mockParts.filter((p) => p.quantity < 0);
  const recentMovements = mockMovements.slice(0, 5);
  const pendingApprovals = mockMovements.filter((m) => !m.approved);

  const totalValue = mockParts.reduce((sum, part) => sum + part.price * part.quantity, 0);

  return (
    <Layout title="Панель управления">
      <div className={styles.dashboard}>
        <div className={styles.statsGrid}>
          <div className={styles.statCard}>
            <div className={styles.statHeader}>
              <h3 className={styles.statLabel}>Всего запчастей</h3>
              <Package className={styles.statIcon} />
            </div>
            <p className={styles.statValue}>{totalParts}</p>
            <p className={styles.statTrend}>В справочнике</p>
          </div>

          <div className={styles.statCard}>
            <div className={styles.statHeader}>
              <h3 className={styles.statLabel}>Низкий остаток</h3>
              <AlertTriangle className={`${styles.statIcon} ${styles.warning}`} />
            </div>
            <p className={styles.statValue}>{lowStockParts.length}</p>
            <p className={styles.statTrend}>Требуют пополнения</p>
          </div>

          <div className={styles.statCard}>
            <div className={styles.statHeader}>
              <h3 className={styles.statLabel}>Отрицательный остаток</h3>
              <TrendingDown className={`${styles.statIcon} ${styles.error}`} />
            </div>
            <p className={styles.statValue}>{negativeStockParts.length}</p>
            <p className={styles.statTrend}>Критическая ситуация</p>
          </div>

          <div className={styles.statCard}>
            <div className={styles.statHeader}>
              <h3 className={styles.statLabel}>Общая стоимость</h3>
              <Package className={`${styles.statIcon} ${styles.success}`} />
            </div>
            <p className={styles.statValue}>{totalValue.toLocaleString("ru-RU")} ₽</p>
            <p className={styles.statTrend}>На складе</p>
          </div>
        </div>

        {(lowStockParts.length > 0 || negativeStockParts.length > 0) && (
          <div className={styles.section}>
            <div className={styles.sectionHeader}>
              <h2 className={styles.sectionTitle}>Критические уведомления</h2>
            </div>
            <div className={styles.alertsList}>
              {negativeStockParts.map((part) => (
                <div key={part.id} className={`${styles.alertItem} ${styles.critical}`}>
                  <AlertTriangle className={styles.alertIcon} />
                  <div className={styles.alertContent}>
                    <h4 className={styles.alertTitle}>Отрицательный остаток</h4>
                    <p className={styles.alertDescription}>
                      {part.name} ({part.article}) - остаток: {part.quantity} шт. Требуется срочное пополнение!
                    </p>
                  </div>
                </div>
              ))}
              {lowStockParts
                .filter((p) => p.quantity >= 0)
                .map((part) => (
                  <div key={part.id} className={styles.alertItem}>
                    <AlertTriangle className={styles.alertIcon} />
                    <div className={styles.alertContent}>
                      <h4 className={styles.alertTitle}>Низкий остаток</h4>
                      <p className={styles.alertDescription}>
                        {part.name} ({part.article}) - остаток: {part.quantity} шт. (мин: {part.minQuantity} шт.)
                      </p>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

        <div className={styles.section}>
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Последние перемещения</h2>
          </div>
          <div className={styles.recentList}>
            {recentMovements.map((movement) => (
              <div key={movement.id} className={styles.recentItem}>
                <ArrowLeftRight className={styles.recentIcon} />
                <div className={styles.recentContent}>
                  <h4 className={styles.recentTitle}>
                    {movement.partName} ({movement.partArticle})
                  </h4>
                  <p className={styles.recentMeta}>
                    {movement.from} → {movement.to} • {movement.userName}
                  </p>
                </div>
                <div className={styles.recentTime}>
                  <Clock style={{ width: "14px", height: "14px", display: "inline", marginRight: "4px" }} />
                  {new Date(movement.timestamp).toLocaleDateString("ru-RU")}
                </div>
              </div>
            ))}
          </div>
        </div>

        {pendingApprovals.length > 0 && (
          <div className={styles.section}>
            <div className={styles.sectionHeader}>
              <h2 className={styles.sectionTitle}>Ожидают подтверждения ({pendingApprovals.length})</h2>
            </div>
            <div className={styles.recentList}>
              {pendingApprovals.map((movement) => (
                <div key={movement.id} className={styles.recentItem}>
                  <CheckCircle className={styles.recentIcon} />
                  <div className={styles.recentContent}>
                    <h4 className={styles.recentTitle}>
                      {movement.partName} -{" "}
                      {movement.type === "issue" ? "Выдача" : movement.type === "return" ? "Возврат" : "Списание"}
                    </h4>
                    <p className={styles.recentMeta}>
                      Количество: {movement.quantity} шт. • {movement.userName}
                    </p>
                  </div>
                  <div className={styles.recentTime}>{new Date(movement.timestamp).toLocaleDateString("ru-RU")}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
