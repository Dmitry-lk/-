import { Layout } from "~/components/layout/layout";
import { mockEquipment } from "~/data/equipment";
import { Button } from "~/components/ui/button/button";
import { FileText, Wrench } from "lucide-react";
import styles from "./equipment.module.css";
import type { Route } from "./+types/equipment";

export function meta({}: Route.MetaArgs) {
  return [
    { title: "Реестр оборудования - Складской учет" },
    {
      name: "description",
      content: "Каталог оборудования с паспортами TOIR",
    },
  ];
}

const STATUS_LABELS: Record<string, string> = {
  operational: "В работе",
  maintenance: "ТО",
  repair: "Ремонт",
  inactive: "Не активно",
};

export default function Equipment() {
  return (
    <Layout title="Реестр оборудования">
      <div className={styles.container}>
        <div className={styles.equipmentGrid}>
          {mockEquipment.map((equipment) => (
            <div key={equipment.id} className={styles.equipmentCard}>
              <div className={styles.equipmentHeader}>
                <div className={styles.equipmentTitle}>
                  <h3 className={styles.equipmentName}>{equipment.name}</h3>
                  <p className={styles.equipmentModel}>Модель: {equipment.model}</p>
                </div>
                <span className={`${styles.statusBadge} ${styles[equipment.status]}`}>
                  {STATUS_LABELS[equipment.status]}
                </span>
              </div>

              <div className={styles.equipmentBody}>
                <div className={styles.equipmentField}>
                  <span className={styles.fieldLabel}>Серийный номер:</span>
                  <span className={styles.fieldValue}>{equipment.serialNumber}</span>
                </div>

                <div className={styles.equipmentField}>
                  <span className={styles.fieldLabel}>Категория:</span>
                  <span className={styles.fieldValue}>{equipment.category}</span>
                </div>

                <div className={styles.equipmentField}>
                  <span className={styles.fieldLabel}>Расположение:</span>
                  <span className={styles.fieldValue}>{equipment.location}</span>
                </div>

                {equipment.passportNumber && (
                  <div className={styles.equipmentField}>
                    <span className={styles.fieldLabel}>Паспорт:</span>
                    <span className={styles.fieldValue}>{equipment.passportNumber}</span>
                  </div>
                )}

                <div className={styles.equipmentField}>
                  <span className={styles.fieldLabel}>Дата установки:</span>
                  <span className={styles.fieldValue}>
                    {new Date(equipment.installDate).toLocaleDateString("ru-RU")}
                  </span>
                </div>

                {equipment.lastMaintenance && (
                  <div className={styles.equipmentField}>
                    <span className={styles.fieldLabel}>Последнее ТО:</span>
                    <span className={styles.fieldValue}>
                      {new Date(equipment.lastMaintenance).toLocaleDateString("ru-RU")}
                    </span>
                  </div>
                )}

                {equipment.nextMaintenance && (
                  <div className={styles.equipmentField}>
                    <span className={styles.fieldLabel}>Следующее ТО:</span>
                    <span className={styles.fieldValue}>
                      {new Date(equipment.nextMaintenance).toLocaleDateString("ru-RU")}
                    </span>
                  </div>
                )}
              </div>

              <div className={styles.equipmentFooter}>
                <Button variant="outline" size="sm" style={{ flex: 1 }}>
                  <FileText style={{ width: "14px", height: "14px", marginRight: "6px" }} />
                  Паспорт
                </Button>
                <Button variant="outline" size="sm" style={{ flex: 1 }}>
                  <Wrench style={{ width: "14px", height: "14px", marginRight: "6px" }} />
                  История
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  );
}
