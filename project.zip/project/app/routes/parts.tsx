import { useState } from "react";
import { Layout } from "~/components/layout/layout";
import { mockParts, PARTS_CATEGORIES } from "~/data/parts";
import { Search, Filter } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "~/components/ui/select/select";
import { Button } from "~/components/ui/button/button";
import styles from "./parts.module.css";
import type { Route } from "./+types/parts";

export function meta({}: Route.MetaArgs) {
  return [
    { title: "Справочник запчастей - Складской учет" },
    {
      name: "description",
      content: "Каталог запчастей с синхронизацией из 1С",
    },
  ];
}

export default function Parts() {
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [conditionFilter, setConditionFilter] = useState<string>("all");

  const filteredParts = mockParts.filter((part) => {
    const matchesSearch =
      part.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      part.article.toLowerCase().includes(searchQuery.toLowerCase()) ||
      part.oemNumber.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = categoryFilter === "all" || part.category === categoryFilter;
    const matchesCondition = conditionFilter === "all" || part.condition === conditionFilter;

    return matchesSearch && matchesCategory && matchesCondition;
  });

  const getConditionLabel = (condition: string) => {
    switch (condition) {
      case "new":
        return "Новая";
      case "used":
        return "Б/У";
      case "repaired":
        return "Восстановленная";
      default:
        return condition;
    }
  };

  const getQuantityClass = (part: (typeof mockParts)[0]) => {
    if (part.quantity < 0) return styles.negative;
    if (part.quantity <= part.minQuantity) return styles.low;
    return styles.normal;
  };

  return (
    <Layout title="Справочник запчастей">
      <div className={styles.container}>
        <div className={styles.toolbar}>
          <div className={styles.searchBox}>
            <Search className={styles.searchIcon} />
            <input
              type="text"
              placeholder="Поиск по наименованию, артикулу, OEM..."
              className={styles.searchInput}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className={styles.filters}>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger style={{ width: "200px" }}>
                <SelectValue placeholder="Категория" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все категории</SelectItem>
                {PARTS_CATEGORIES.map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={conditionFilter} onValueChange={setConditionFilter}>
              <SelectTrigger style={{ width: "180px" }}>
                <SelectValue placeholder="Состояние" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все состояния</SelectItem>
                <SelectItem value="new">Новые</SelectItem>
                <SelectItem value="used">Б/У</SelectItem>
                <SelectItem value="repaired">Восстановленные</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline">
              <Filter style={{ width: "16px", height: "16px", marginRight: "8px" }} />
              Фильтры
            </Button>
          </div>
        </div>

        <div className={styles.tableContainer}>
          <table className={styles.table}>
            <thead>
              <tr>
                <th>Фото</th>
                <th>Наименование</th>
                <th>OEM-номер</th>
                <th>Категория</th>
                <th>Остаток</th>
                <th>Состояние</th>
                <th>Цена</th>
                <th>Поставщик</th>
                <th>Расположение</th>
                <th>Дата поступления</th>
              </tr>
            </thead>
            <tbody>
              {filteredParts.map((part) => (
                <tr key={part.id}>
                  <td>{part.imageUrl && <img src={part.imageUrl} alt={part.name} className={styles.partImage} />}</td>
                  <td>
                    <div>
                      <p className={styles.partName}>{part.name}</p>
                      <p className={styles.partArticle}>{part.article}</p>
                    </div>
                  </td>
                  <td>{part.oemNumber}</td>
                  <td>{part.category}</td>
                  <td>
                    <span className={`${styles.quantity} ${getQuantityClass(part)}`}>{part.quantity} шт.</span>
                    <div style={{ fontSize: "var(--font-size-0)", color: "var(--color-neutral-10)", marginTop: "4px" }}>
                      мин: {part.minQuantity}
                    </div>
                  </td>
                  <td>
                    <span className={`${styles.badge} ${styles[part.condition]}`}>
                      {getConditionLabel(part.condition)}
                    </span>
                  </td>
                  <td>
                    <span className={styles.price}>{part.price.toLocaleString("ru-RU")} ₽</span>
                  </td>
                  <td>{part.supplier}</td>
                  <td>{part.location}</td>
                  <td>{new Date(part.dateReceived).toLocaleDateString("ru-RU")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </Layout>
  );
}
