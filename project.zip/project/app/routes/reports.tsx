import { Layout } from "~/components/layout/layout";
import { FileText, TrendingDown, Package, ArrowLeftRight, AlertTriangle, BarChart3 } from "lucide-react";
import styles from "./reports.module.css";
import type { Route } from "./+types/reports";

export function meta({}: Route.MetaArgs) {
  return [
    { title: "Отчеты - Складской учет" },
    {
      name: "description",
      content: "Аналитические отчеты и статистика",
    },
  ];
}

const REPORTS = [
  {
    id: "inventory",
    title: "Отчет по остаткам",
    description: "Текущие остатки запчастей на складе с группировкой по категориям",
    icon: Package,
  },
  {
    id: "movements",
    title: "История перемещений",
    description: "Полная история движения запчастей за выбранный период",
    icon: ArrowLeftRight,
  },
  {
    id: "low-stock",
    title: "Низкие остатки",
    description: "Запчасти с остатком ниже минимального уровня",
    icon: TrendingDown,
  },
  {
    id: "negative",
    title: "Отрицательные остатки",
    description: "Критические позиции с отрицательным остатком",
    icon: AlertTriangle,
  },
  {
    id: "value",
    title: "Стоимостной анализ",
    description: "Анализ стоимости запчастей на складе",
    icon: BarChart3,
  },
  {
    id: "documents",
    title: "Документы 1С",
    description: "Сформированные документы для выгрузки в 1С",
    icon: FileText,
  },
];

export default function Reports() {
  return (
    <Layout title="Отчеты">
      <div className={styles.container}>
        <div className={styles.reportGrid}>
          {REPORTS.map((report) => {
            const Icon = report.icon;
            return (
              <div key={report.id} className={styles.reportCard}>
                <Icon className={styles.reportIcon} />
                <h3 className={styles.reportTitle}>{report.title}</h3>
                <p className={styles.reportDescription}>{report.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </Layout>
  );
}
