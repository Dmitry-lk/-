import { Layout } from "~/components/layout/layout";
import { Button } from "~/components/ui/button/button";
import { RefreshCw, Bell, FileText, Database } from "lucide-react";
import styles from "./settings.module.css";
import type { Route } from "./+types/settings";

export function meta({}: Route.MetaArgs) {
  return [
    { title: "Настройки - Складской учет" },
    {
      name: "description",
      content: "Настройки системы и интеграции",
    },
  ];
}

export default function Settings() {
  return (
    <Layout title="Настройки">
      <div className={styles.container}>
        <div className={styles.section}>
          <h2 className={styles.sectionTitle}>Интеграция с 1С</h2>

          <div className={styles.settingItem}>
            <div className={styles.settingInfo}>
              <h3 className={styles.settingLabel}>Синхронизация справочника</h3>
              <p className={styles.settingDescription}>Автоматическая синхронизация номенклатуры запчастей из 1С</p>
            </div>
            <Button className={styles.syncButton}>
              <RefreshCw style={{ width: "16px", height: "16px" }} />
              Синхронизировать
            </Button>
          </div>

          <div className={styles.settingItem}>
            <div className={styles.settingInfo}>
              <h3 className={styles.settingLabel}>Выгрузка документов</h3>
              <p className={styles.settingDescription}>
                Автоматическая генерация документов 1С после подтверждения ЛПР
              </p>
            </div>
            <Button variant="outline">
              <FileText style={{ width: "16px", height: "16px", marginRight: "6px" }} />
              Настроить
            </Button>
          </div>
        </div>

        <div className={styles.section}>
          <h2 className={styles.sectionTitle}>Уведомления</h2>

          <div className={styles.settingItem}>
            <div className={styles.settingInfo}>
              <h3 className={styles.settingLabel}>Telegram уведомления</h3>
              <p className={styles.settingDescription}>Отправка уведомлений о критически низких остатках в Telegram</p>
            </div>
            <Button variant="outline">
              <Bell style={{ width: "16px", height: "16px", marginRight: "6px" }} />
              Настроить
            </Button>
          </div>

          <div className={styles.settingItem}>
            <div className={styles.settingInfo}>
              <h3 className={styles.settingLabel}>Пороговые значения</h3>
              <p className={styles.settingDescription}>Настройка минимальных остатков для уведомлений</p>
            </div>
            <Button variant="outline">Изменить</Button>
          </div>
        </div>

        <div className={styles.section}>
          <h2 className={styles.sectionTitle}>Система</h2>

          <div className={styles.settingItem}>
            <div className={styles.settingInfo}>
              <h3 className={styles.settingLabel}>База данных</h3>
              <p className={styles.settingDescription}>Резервное копирование и восстановление данных</p>
            </div>
            <Button variant="outline">
              <Database style={{ width: "16px", height: "16px", marginRight: "6px" }} />
              Управление
            </Button>
          </div>
        </div>
      </div>
    </Layout>
  );
}
