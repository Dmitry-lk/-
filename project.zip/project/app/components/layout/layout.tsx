import { NavLink } from "react-router";
import { LayoutDashboard, Package, ArrowLeftRight, Wrench, FileText, Settings, User, Warehouse } from "lucide-react";
import styles from "./layout.module.css";

interface LayoutProps {
  children: React.ReactNode;
  /**
   * The title of the current page
   * @important
   */
  title: string;
}

export function Layout({ children, title }: LayoutProps) {
  return (
    <div className={styles.layout}>
      <aside className={styles.sidebar}>
        <div className={styles.header}>
          <h1 className={styles.logo}>
            <Warehouse className={styles.logoIcon} />
            Складской учет
          </h1>
        </div>

        <nav className={styles.nav}>
          <ul className={styles.navList}>
            <li className={styles.navItem}>
              <NavLink to="/" className={styles.navLink} end>
                <LayoutDashboard className={styles.navIcon} />
                Панель управления
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink to="/parts" className={styles.navLink}>
                <Package className={styles.navIcon} />
                Справочник запчастей
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink to="/movements" className={styles.navLink}>
                <ArrowLeftRight className={styles.navIcon} />
                Движение запчастей
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink to="/equipment" className={styles.navLink}>
                <Wrench className={styles.navIcon} />
                Реестр оборудования
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink to="/reports" className={styles.navLink}>
                <FileText className={styles.navIcon} />
                Отчеты
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink to="/settings" className={styles.navLink}>
                <Settings className={styles.navIcon} />
                Настройки
              </NavLink>
            </li>
          </ul>
        </nav>
      </aside>

      <main className={styles.main}>
        <div className={styles.topbar}>
          <div className={styles.topbarLeft}>
            <h2 className={styles.pageTitle}>{title}</h2>
          </div>
          <div className={styles.topbarRight}>
            <div className={styles.userInfo}>
              <User className={styles.userIcon} />
              <span className={styles.userName}>Администратор</span>
            </div>
          </div>
        </div>

        <div className={styles.content}>{children}</div>
      </main>
    </div>
  );
}
