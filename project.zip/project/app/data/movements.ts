export interface Movement {
  id: string;
  partId: string;
  partName: string;
  partArticle: string;
  type: "issue" | "return" | "writeoff" | "transfer" | "repair" | "disassembly";
  quantity: number;
  from: string;
  to: string;
  equipmentId?: string;
  equipmentName?: string;
  userId: string;
  userName: string;
  timestamp: string;
  comment?: string;
  photosBefore?: string[];
  photosAfter?: string[];
  documentNumber?: string;
  approved: boolean;
  approvedBy?: string;
  approvedAt?: string;
}

export const mockMovements: Movement[] = [
  {
    id: "1",
    partId: "1",
    partName: "Подшипник радиальный",
    partArticle: "ПР-6205",
    type: "issue",
    quantity: 2,
    from: "Склад А, стеллаж 3",
    to: "Цех 1, станок РМ-200",
    equipmentId: "eq-1",
    equipmentName: "Кромкообрезной станок РМ-200",
    userId: "user-1",
    userName: "Иванов Петр Сергеевич",
    timestamp: "2024-03-15T10:30:00",
    comment: "Плановая замена подшипников на станке РМ-200",
    photosBefore: ["https://images.unsplash.com/photo-1565793298595-6a879b1d9492?w=400"],
    photosAfter: ["https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=400"],
    documentNumber: "ТН-2024-0315-001",
    approved: true,
    approvedBy: "Сидоров А.В.",
    approvedAt: "2024-03-15T11:00:00",
  },
  {
    id: "2",
    partId: "4",
    partName: "Пильный диск 450мм",
    partArticle: "ПД-450-60Т",
    type: "issue",
    quantity: 5,
    from: "Склад А, стеллаж 5",
    to: "Цех 2, пилорама ПР-500",
    equipmentId: "eq-2",
    equipmentName: "Пилорама ПР-500",
    userId: "user-2",
    userName: "Смирнов Алексей Иванович",
    timestamp: "2024-03-14T14:20:00",
    comment: "Срочная замена изношенных дисков",
    photosBefore: ["https://images.unsplash.com/photo-1572981779307-38b8cabb2407?w=400"],
    documentNumber: "ТН-2024-0314-002",
    approved: true,
    approvedBy: "Сидоров А.В.",
    approvedAt: "2024-03-14T15:00:00",
  },
  {
    id: "3",
    partId: "2",
    partName: "Ремень приводной",
    partArticle: "РП-SPZ-1250",
    type: "return",
    quantity: 1,
    from: "Цех 1, станок РМ-150",
    to: "Склад А, стеллаж 1",
    equipmentId: "eq-3",
    equipmentName: "Кромкообрезной станок РМ-150",
    userId: "user-1",
    userName: "Иванов Петр Сергеевич",
    timestamp: "2024-03-13T16:45:00",
    comment: "Возврат неиспользованного ремня после ремонта",
    photosAfter: ["https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=400"],
    documentNumber: "ТН-2024-0313-003",
    approved: false,
  },
  {
    id: "4",
    partId: "6",
    partName: "Вал приводной (восстановленный)",
    partArticle: "ВП-РМ200-01",
    type: "repair",
    quantity: 1,
    from: "Ремонтный участок",
    to: "Склад Б/У, стеллаж 1",
    userId: "user-3",
    userName: "Кузнецов Дмитрий Павлович",
    timestamp: "2024-03-12T09:15:00",
    comment: "Восстановление вала после разборки агрегата",
    photosBefore: ["https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?w=400"],
    photosAfter: ["https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=400"],
    documentNumber: "РМ-2024-0312-001",
    approved: true,
    approvedBy: "Сидоров А.В.",
    approvedAt: "2024-03-12T10:00:00",
  },
  {
    id: "5",
    partId: "3",
    partName: "Электродвигатель 5.5 кВт",
    partArticle: "ЭД-5.5-1500",
    type: "writeoff",
    quantity: 1,
    from: "Цех 3, станок ФС-300",
    to: "Списание",
    equipmentId: "eq-4",
    equipmentName: "Фрезерный станок ФС-300",
    userId: "user-2",
    userName: "Смирнов Алексей Иванович",
    timestamp: "2024-03-11T11:30:00",
    comment: "Двигатель сгорел, восстановлению не подлежит",
    photosBefore: ["https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=400"],
    documentNumber: "СП-2024-0311-001",
    approved: false,
  },
  {
    id: "6",
    partId: "7",
    partName: "Подшипник упорный (б/у)",
    partArticle: "ПУ-51205",
    type: "disassembly",
    quantity: 3,
    from: "Агрегат А-150 (разукомплектация)",
    to: "Склад Б/У, стеллаж 2",
    userId: "user-3",
    userName: "Кузнецов Дмитрий Павлович",
    timestamp: "2024-03-10T13:00:00",
    comment: "Разборка вышедшего из строя агрегата на запчасти",
    photosAfter: ["https://images.unsplash.com/photo-1565793298595-6a879b1d9492?w=400"],
    documentNumber: "РК-2024-0310-001",
    approved: true,
    approvedBy: "Сидоров А.В.",
    approvedAt: "2024-03-10T14:00:00",
  },
];
