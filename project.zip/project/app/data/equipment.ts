export interface Equipment {
  id: string;
  name: string;
  model: string;
  category: string;
  serialNumber: string;
  location: string;
  status: "operational" | "maintenance" | "repair" | "inactive";
  passportNumber?: string;
  installDate: string;
  lastMaintenance?: string;
  nextMaintenance?: string;
}

export const mockEquipment: Equipment[] = [
  {
    id: "eq-1",
    name: "Кромкообрезной станок РМ-200",
    model: "РМ-200",
    category: "Кромкообрезные станки",
    serialNumber: "RM200-2023-045",
    location: "Цех 1, линия А",
    status: "operational",
    passportNumber: "ПС-001-2023",
    installDate: "2023-05-15",
    lastMaintenance: "2024-03-01",
    nextMaintenance: "2024-06-01",
  },
  {
    id: "eq-2",
    name: "Пилорама ПР-500",
    model: "ПР-500",
    category: "Пилорамы",
    serialNumber: "PR500-2022-112",
    location: "Цех 2, участок Б",
    status: "operational",
    passportNumber: "ПС-002-2022",
    installDate: "2022-08-20",
    lastMaintenance: "2024-02-15",
    nextMaintenance: "2024-05-15",
  },
  {
    id: "eq-3",
    name: "Кромкообрезной станок РМ-150",
    model: "РМ-150",
    category: "Кромкообрезные станки",
    serialNumber: "RM150-2021-089",
    location: "Цех 1, линия Б",
    status: "maintenance",
    passportNumber: "ПС-003-2021",
    installDate: "2021-11-10",
    lastMaintenance: "2024-03-10",
    nextMaintenance: "2024-04-10",
  },
  {
    id: "eq-4",
    name: "Фрезерный станок ФС-300",
    model: "ФС-300",
    category: "Фрезерные станки",
    serialNumber: "FS300-2023-067",
    location: "Цех 3, участок В",
    status: "repair",
    passportNumber: "ПС-004-2023",
    installDate: "2023-03-25",
    lastMaintenance: "2024-01-20",
    nextMaintenance: "2024-04-20",
  },
  {
    id: "eq-5",
    name: "Торцовочный станок ТС-250",
    model: "ТС-250",
    category: "Торцовочные станки",
    serialNumber: "TS250-2022-134",
    location: "Цех 2, участок А",
    status: "operational",
    passportNumber: "ПС-005-2022",
    installDate: "2022-12-05",
    lastMaintenance: "2024-02-28",
    nextMaintenance: "2024-05-28",
  },
];
