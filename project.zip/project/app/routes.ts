import { type RouteConfig, index, route } from "@react-router/dev/routes";

export default [
  index("routes/home.tsx"),
  route("parts", "routes/parts.tsx"),
  route("movements", "routes/movements.tsx"),
  route("equipment", "routes/equipment.tsx"),
  route("reports", "routes/reports.tsx"),
  route("settings", "routes/settings.tsx"),
] satisfies RouteConfig;
